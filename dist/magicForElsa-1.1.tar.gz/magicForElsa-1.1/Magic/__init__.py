'''This package contains all the neccessary modules needed for Elsa'''
