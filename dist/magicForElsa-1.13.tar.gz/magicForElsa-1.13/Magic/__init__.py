"""This package contains all the neccessary modules needed for Elsa
Modules in the package are:
i)about_page
ii)add_user
iii)file_database
iv)GUI
v)history
vi)indexer
vii)initial_setup
viii)settings
ix)srchpopup
x)theme
xi)tkinterlib
xii)usernames"""
__version__ = 1.13
